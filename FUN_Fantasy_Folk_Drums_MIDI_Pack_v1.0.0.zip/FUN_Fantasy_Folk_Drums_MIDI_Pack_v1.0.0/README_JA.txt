FUN Fantasy Folk Drums MIDI Pack v1.0.0
=====================================

FUNtasia Audio / FUNtasia Studio 無料追加エクスパンション

【内容】
- ファンタジー・フォーク系ドラムのオリジナルMIDI 120ファイル
- 6カテゴリー × 各4グルーヴ × 5バリエーション
- Standard MIDI File（Type 0）、4/4拍子
- GM1互換のドラムノート19種類、MIDIチャンネル10を使用
- 推奨テンポ90〜160 BPM（MIDIにテンポ変更イベントは含みません）
- ジャケット画像：ARTWORK/FUN_Fantasy_Folk_Drums_Cover.png

このパックにはオーディオサンプル、ドラム音源、試聴用WAVは含まれません。
MIDIの音は、DAWで接続したドラム音源やサンプラーによって決まります。

【使い始めるには】
1. ZIPを展開します。インストーラーやライセンス認証は不要です。
2. FUNtasia Studio等の対応DAWへ .mid ファイルを読み込むか、
   ドラッグ＆ドロップでMIDIトラックに配置します。
3. MIDIトラックにドラム音源を接続し、プロジェクトを4/4拍子に設定します。
4. ファイル名のBPM表記は推奨テンポです。実際の再生はDAW側のテンポに従います。

【5つのバリエーション】
- Basic：基本となるドラムグルーヴ
- Perc_Layer：追加のパーカッション・装飾レイヤー
- Layered：BasicとPerc_Layerを同時に重ねたものと同一のMIDI演奏
- Intense：より密度の高い別アレンジ
- Fill：4小節目の置き換えなどに使える1小節のつなぎ

BasicとPerc_Layerを同じ小節頭に並べるとLayeredと同じ演奏になります。
LayeredにさらにBasicとPerc_Layerを重ねると二重発音になる点に注意してください。
Fill以外は4小節、Fillは1小節です。

【互換性とライセンス】
- FUNtasia Studio向けの追加パックですが、対応する他のDAWでも利用できます。
- 音名のオクターブ表示はDAWにより異なるため、GM1_NOTE_MAP.txtの
  MIDIノート番号を基準にしてください。
- 商用・非商用の楽曲や映像等の制作に、追加ロイヤリティなしで利用できます。
- クレジット表記は必須ではありません。
- 独自の創作内容を持つDAWプロジェクトの共有は許可されていますが、
  MIDIそのものを独立した素材集として再配布することは禁止されています。
- 正確な利用範囲・条件は日本語・英語併記のLICENSE.txtをご確認ください。

問い合わせ：info.funtasiaaudio@gmail.com
