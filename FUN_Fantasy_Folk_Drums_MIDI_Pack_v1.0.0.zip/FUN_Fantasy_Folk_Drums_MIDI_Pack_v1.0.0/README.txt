FUN Fantasy Folk Drums MIDI Pack v1.0.0
======================================

FREE FUNtasia Studio EXPANSION PACK

FUN Fantasy Folk Drums is a free optional MIDI expansion for FUNtasia Studio.
Its 120 original drum performances also work as Standard MIDI Files in
compatible third-party DAWs. The Universal ZIP requires no installer,
activation, or purchase.

CONTENTS
- 120 Standard MIDI Files (SMF Type 0) in six category folders:
  4 Groove identities per category, each in five variations.
- 4/4 time signature, 4-bar Grooves, 1-bar Fills.
- Suggested tempos of 90–160 BPM in filenames, with NO embedded tempo events.
- MIDI channel 10, 19 GM1-compatible percussion note numbers.
- Approved jacket artwork: ARTWORK/FUN_Fantasy_Folk_Drums_Cover.png
  (1254 × 1254, RGB PNG).
- A pattern index and MIDI SHA-256 verification manifest.

This pack contains MIDI data ONLY. No WAV previews, audio samples, drum
instruments, or sound-font libraries are bundled.

VARIATIONS
- Basic: core rhythm and primary hand percussion.
- Perc_Layer: auxiliary hand percussion and embellishments.
- Layered: exactly the same MIDI note events as Basic + Perc_Layer placed
  at the same start time (including timing, note, duration, and velocity).
- Intense: a separate, busier musical arrangement.
- Fill: a one-bar transition, designed for placement in bar 4 of a phrase.

Use EITHER Layered OR Basic + Perc_Layer. Stacking all three can duplicate
note events. Import each MIDI file on the song's musical grid and route the
track to your chosen drum instrument.

COMPATIBILITY
- All files use 4/4 and have no embedded tempo, program-change, or SysEx events.
- The project/host sets the playback tempo; filenames show recommended BPM.
- Refer to GM1_NOTE_MAP.txt for percussion note numbers. DAWs differ in their
  displayed octave names, so MIDI numbers are authoritative.
- Generic GM drums provide approximate percussion sounds, not sampled
  Davul, Bendir, or Darbuka sounds. Results depend on the chosen instrument.

LICENSE
- Commercial and personal Creative Works: royalty-free, no attribution needed.
- Sharing substantial original DAW projects with editable MIDI is allowed
  under the project-specific conditions in LICENSE.txt.
- Redistributing the original or recognizable MIDI performances as standalone
  packs, stock loops, or disguised asset collections is not permitted.
- See LICENSE.txt for the authoritative full terms in Japanese and English.
  Where interpretations differ, the Japanese text prevails.

FURTHER HELP
- README_JA.txt: Japanese introduction and usage guide.
- INSTALL_GUIDE.txt: fuller English setup and layering instructions.
- GM1_NOTE_MAP.txt: the 19 percussion note numbers.
- PATTERN_INDEX.json: structured index of the 120 MIDI files.
- SHA256_MIDI.txt: manifest for checking the unchanged MIDI bytes.

Publisher: FUNtasia Audio (individually operated)
Contact: info.funtasiaaudio@gmail.com
